REDIS_HOST='localhost'
REDIS_PORT=6379
REDIS_DB=0
DATA='data/test.json'